
n = int(input("Enter number of elements: "))

s1 = set()

for i in range(n):
    num = input("Enter element: ")
    s1.add(num)

# Copy elements one by one into a new set
s2 = set()

for i in s1:
    s2.add(i)

# Display both sets
print("Original Set:", s1)
print("New Copied Set:", s2)