# Input for first set
n1 = int(input("Enter number of elements in first set: "))
set1 = set()
for i in range(n1):
    element = input("Enter element for first set: ")
    set1.add(element)

# Input for second set
n2 = int(input("Enter number of elements in second set: "))
set2 = set()
for i in range(n2):
    element = input("Enter element for second set: ")
    set2.add(element)

print("\nFirst Set:", set1)
print("Second Set:", set2)

union_set = set1 | set2
print("\nUnion:", union_set)

intersection_set = set1 & set2
print("Intersection:", intersection_set)

difference_set1 = set1 - set2
print("Difference (set1 - set2):", difference_set1)


difference_set2 = set2 - set1
print("Difference (set2 - set1):", difference_set2)

sym_diff = set1 ^ set2
print("Symmetric Difference:", sym_diff)