# Enter a five digit number
num = input("Enter a five digit number: ")

if len(num) == 5:
    print("Digits at odd positions are:")
    print(num[0])
    print(num[2])
    print(num[4])
else:
    print("Please enter a valid five digit number.")