# Input order of the matrix
n = int(input("Enter n: "))

# Input matrix elements
matrix = []
for i in range(n):
    row = list(map(int, input().split()))  # simpler input
    matrix.append(row)

# Print transpose
print("Transpose of the matrix:")
for i in range(n):
    for j in range(n):
        print(matrix[j][i], end=" ")
    print()