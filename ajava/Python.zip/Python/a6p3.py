n1 = int(input("Enter number of elements in first set: "))
set1 = set()
for i in range(n1):
    element = input("Enter element for first set: ")
    set1.add(element)

n2 = int(input("Enter number of elements in second set: "))
set2 = set()
for i in range(n2):
    element = input("Enter element for second set: ")
    set2.add(element)


com = set1 | set2  


print("Combined set without duplicates:", com)