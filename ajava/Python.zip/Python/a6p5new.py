# Input 3x3 matrix
matrix = []
print("Enter 3x3 matrix row by row:")
for i in range(3):
    row = list(map(int, input().split()))
    matrix.append(row)

# Calculate row sums and column sums
row_sums = []
col_sums = [0, 0, 0]

for i in range(3):
    row_sum = sum(matrix[i])
    row_sums.append(row_sum)
    for j in range(3):
        col_sums[j] += matrix[i][j]

# Print matrix with row sums
print("\nMatrix with row sums:")
for i in range(3):
    for j in range(3):
        print(f"{matrix[i][j]:>4}", end="")  # align numbers
    print(f"{row_sums[i]:>4}")  # row sum at end

# Print column sums with empty space for 4th column
for j in range(3):
    print(f"{col_sums[j]:>4}", end="")
print(f"{'':>4}")  # empty space for row sums column