matrix = []
print("Enter 3x3 matrix row by row:")
for i in range(3):
    row = list(map(int, input().split()))
    matrix.append(row)

row_sums = []
col_sums = [0, 0, 0]

for i in range(3):
    row_sum = sum(matrix[i])
    row_sums.append(row_sum)
    for j in range(3):
        col_sums[j] += matrix[i][j]

for i in range(3):
    for j in range(3):
        print(matrix[i][j], end=" ")
    print(row_sums[i])  


for sum_col in col_sums:
    print(sum_col, end=" ")